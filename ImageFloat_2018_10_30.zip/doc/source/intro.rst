Introduction
============

User Interface
++++++++++++++

Menu Bar
--------

Toolbox
-------

Image Panel
-----------

Image Information Panel
-----------------------

Histogram Panel
---------------

Parameter Panel
---------------

Status Bar
----------

Interaction
+++++++++++

Processing Pipelines
++++++++++++++++++++

Nodes
-----

Parameters
----------

Ports
-----

Links
-----

Graphs
------

Processing Pipeline Execution
+++++++++++++++++++++++++++++
