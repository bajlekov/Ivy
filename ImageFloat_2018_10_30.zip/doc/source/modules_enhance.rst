Enhance modules
===============

These modules offer tools for local adjustments of the image being processed. The performed operations depend on the neighboring image details at different scales.
