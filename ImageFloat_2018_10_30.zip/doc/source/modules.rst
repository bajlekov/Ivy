Modules
=======

ImageFloat's processing pipeline consists of modules chained together, each performing a specific processing step. the available modules are divided into several categories dependent on the type of operation they perform.

.. toctree::
	:maxdepth: 2

	modules_adjust
	modules_enhance
