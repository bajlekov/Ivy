Subset of RawTherapee Film Simulation Collection version 2015-09-20 CC BY-SA 4.0

Credits:
Pat David - http://rawtherapee.com/forum/memberlist.php?mode=viewprofile&u=5101
Pavlov Dmitry - http://rawtherapee.com/forum/memberlist.php?mode=viewprofile&u=5592
Michael Ezra - http://rawtherapee.com/forum/memberlist.php?mode=viewprofile&u=1442

Disclaimer:
The trademarked names which may appear in the filenames of the Hald CLUT images are there for informational purposes only. They serve only to inform the user which film stock the given Hald CLUT image is designed to approximate. As there is no way to convey this information other than by using the trademarked name, we believe this constitutes fair use. Neither the publisher nor the authors are affiliated with or endorsed by the companies that own the trademarks.
