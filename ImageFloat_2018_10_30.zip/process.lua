do local _={
  links={
    input={
      [0]={
        output={
          [0]=true
        }
      }
    }
  },
  nodes={
    output={
      y=91,
      x=1030,
      elem={
        true,
        false
      }
    },
    input={
      y=200,
      x=300,
      elem={}
    }
  }
}
return _
end